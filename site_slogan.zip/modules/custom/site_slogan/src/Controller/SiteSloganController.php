<?php

namespace Drupal\site_slogan\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Provides a route callback that displays the current site slogan.
 */
class SiteSloganController extends ControllerBase {

  /**
   * Returns markup with the current site slogan.
   */
  public function view(): array {
    $slogan = $this->config('system.site')->get('slogan') ?: $this->t('No site slogan has been configured yet.');

    return [
      '#theme' => 'item_list',
      '#title' => $this->t('Current site slogan'),
      '#items' => [
        $slogan,
      ],
      '#attached' => [
        'library' => [],
      ],
    ];
  }

}

