<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_contact_form
 *
 * @copyright   (C) 2024 Lab3. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;
?>

<div class="mod-contact-form<?php echo $moduleclass_sfx; ?>" style="--form-color: <?php echo $form_color; ?>;">
    <div class="contact-form-container">
        <!-- Кнопка для сворачивания/разворачивания -->
        <button type="button" class="contact-form-toggle" id="contactFormToggle">
            <span class="toggle-text"><?php echo $button_text; ?></span>
            <span class="toggle-icon">▼</span>
        </button>
        
        <!-- Форма контактов -->
        <div class="contact-form" id="contactForm" style="display: none;">
            <h3 class="form-title"><?php echo $form_title; ?></h3>
            
            <form action="<?php echo Route::_('index.php'); ?>" method="post" id="contactFormForm" class="contact-form-fields">
                <input type="hidden" name="option" value="com_ajax" />
                <input type="hidden" name="module" value="contact_form" />
                <input type="hidden" name="format" value="json" />
                <input type="hidden" name="task" value="get" />
                <input type="hidden" name="module_id" value="<?php echo $module->id; ?>" />
                <?php echo HTMLHelper::_('form.token'); ?>
                
                <div class="form-group">
                    <label for="contact_name"><?php echo Text::_('MOD_CONTACT_FORM_NAME_LABEL'); ?> *</label>
                    <input type="text" id="contact_name" name="name" required class="form-control" />
                </div>
                
                <div class="form-group">
                    <label for="contact_email"><?php echo Text::_('MOD_CONTACT_FORM_EMAIL_LABEL'); ?> *</label>
                    <input type="email" id="contact_email" name="email" required class="form-control" />
                </div>
                
                <div class="form-group">
                    <label for="contact_message"><?php echo Text::_('MOD_CONTACT_FORM_MESSAGE_LABEL'); ?> *</label>
                    <textarea id="contact_message" name="message" required class="form-control" rows="4"></textarea>
                </div>
                
                <?php if ($show_captcha): ?>
                <div class="form-group captcha-group">
                    <label for="contact_captcha"><?php echo Text::_('MOD_CONTACT_FORM_CAPTCHA_LABEL'); ?> *</label>
                    <div class="captcha-container">
                        <span class="captcha-question"><?php echo $num1; ?> + <?php echo $num2; ?> = ?</span>
                        <input type="number" id="contact_captcha" name="captcha" required class="form-control captcha-input" />
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="refreshCaptcha" title="Refresh captcha">🔄</button>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary submit-btn">
                        <?php echo Text::_('MOD_CONTACT_FORM_SEND_BUTTON'); ?>
                    </button>
                    <button type="button" class="btn btn-secondary cancel-btn" id="cancelForm">
                        <?php echo Text::_('MOD_CONTACT_FORM_CANCEL_BUTTON'); ?>
                    </button>
                </div>
                
                <div class="form-message" id="formMessage" style="display: none;"></div>
            </form>
        </div>
    </div>
</div>
