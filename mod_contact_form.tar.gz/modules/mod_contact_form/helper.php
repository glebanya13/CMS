<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_contact_form
 *
 * @copyright   (C) 2024 Lab3. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Mail\Mail;
use Joomla\CMS\Session\Session;

/**
 * Helper class for mod_contact_form
 */
class ModContactFormHelper
{
    /**
     * AJAX method to send contact form message
     *
     * @return array
     */
    public static function getAjax()
    {
        return self::sendMessageAjax();
    }

    /**
     * AJAX method to send contact form message
     *
     * @return array
     */
    public static function sendMessageAjax()
    {
        $app = Factory::getApplication();
        $input = $app->getInput();
        
        // Проверяем CSRF токен
        if (!Session::checkToken('post')) {
            return [
                'success' => false,
                'message' => 'Invalid security token'
            ];
        }
        
        // Получаем данные формы
        $name = $input->post->getString('name', '');
        $email = $input->post->getString('email', '');
        $message = $input->post->getString('message', '');
        $captcha = $input->post->getInt('captcha', 0);
        
        // Валидация данных
        if (empty($name) || empty($email) || empty($message)) {
            return [
                'success' => false,
                'message' => 'All fields are required'
            ];
        }
        
        // Проверка email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return [
                'success' => false,
                'message' => 'Invalid email format'
            ];
        }
        
        // Проверка капчи
        $session = Factory::getSession();
        $captcha_answer = $session->get('contact_form_captcha', 0);
        
        if ($captcha !== $captcha_answer) {
            return [
                'success' => false,
                'message' => 'Invalid captcha answer'
            ];
        }
        
        // Получаем email администратора из параметров модуля
        $moduleId = $input->post->getInt('module_id', 0);
        $adminEmail = 'admin@lab3.com'; // По умолчанию
        
        if ($moduleId) {
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('params')
                ->from('#__modules')
                ->where('id = ' . $moduleId);
            $db->setQuery($query);
            $params = $db->loadResult();
            
            if ($params) {
                $params = json_decode($params, true);
                if (isset($params['admin_email'])) {
                    $adminEmail = $params['admin_email'];
                }
            }
        }
        
        // Отправляем email
        try {
            $mailer = Factory::getMailer();
            $mailer->setSender([$email, $name]);
            $mailer->addRecipient($adminEmail);
            $mailer->setSubject('Website message from ' . $name);
            
            $body = "Name: " . $name . "\n";
            $body .= "Email: " . $email . "\n";
            $body .= "Message:\n" . $message . "\n";
            $body .= "\nSent on: " . date('Y-m-d H:i:s');
            
            $mailer->setBody($body);
            $mailer->isHTML(false);
            
            $result = $mailer->Send();
            
            if ($result === true) {
                // Очищаем капчу из сессии
                $session->clear('contact_form_captcha');
                
                return [
                    'success' => true,
                    'message' => 'Message sent successfully!'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Error sending message'
                ];
            }
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error sending message: ' . $e->getMessage()
            ];
        }
    }
}
