<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_contact_form
 *
 * @copyright   (C) 2024 Lab3. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

// Load language file
$lang = Factory::getLanguage();
$lang->load('mod_contact_form', JPATH_SITE);

// Получаем параметры модуля
$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx', ''), ENT_COMPAT, 'UTF-8');
$form_title = $params->get('form_title', 'Contact Us');
$button_text = $params->get('button_text', 'Write to Us');
$admin_email = $params->get('admin_email', 'admin@lab3.com');
$form_color = $params->get('form_color', '#007cba');
$show_captcha = $params->get('show_captcha', 1);

// Генерируем случайные числа для капчи
$num1 = rand(1, 10);
$num2 = rand(1, 10);
$captcha_answer = $num1 + $num2;

// Сохраняем ответ в сессии
$session = Factory::getSession();
$session->set('contact_form_captcha', $captcha_answer);

// Подключаем CSS и JS
$document = Factory::getDocument();
$document->addStyleSheet(Uri::root() . 'modules/mod_contact_form/media/style.css');
$document->addScript(Uri::root() . 'modules/mod_contact_form/media/script.js');

require ModuleHelper::getLayoutPath('mod_contact_form', $params->get('layout', 'default'));
