/**
 * JavaScript для модуля формы контактов
 */
document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.getElementById('contactFormToggle');
    const contactForm = document.getElementById('contactForm');
    const cancelBtn = document.getElementById('cancelForm');
    const form = document.getElementById('contactFormForm');
    const formMessage = document.getElementById('formMessage');
    
    if (!toggleBtn || !contactForm) return;
    
    // Обработчик клика по кнопке переключения
    toggleBtn.addEventListener('click', function() {
        if (contactForm.style.display === 'none' || contactForm.style.display === '') {
            // Показываем форму
            contactForm.style.display = 'block';
            toggleBtn.classList.add('expanded');
            toggleBtn.querySelector('.toggle-text').textContent = 'Collapse Form';
        } else {
            // Скрываем форму
            contactForm.style.display = 'none';
            toggleBtn.classList.remove('expanded');
            toggleBtn.querySelector('.toggle-text').textContent = toggleBtn.querySelector('.toggle-text').getAttribute('data-original-text') || 'Write to Us';
        }
    });
    
    // Сохраняем оригинальный текст кнопки
    const originalText = toggleBtn.querySelector('.toggle-text').textContent;
    toggleBtn.querySelector('.toggle-text').setAttribute('data-original-text', originalText);
    
    // Обработчик кнопки обновления капчи
    const refreshCaptchaBtn = document.getElementById('refreshCaptcha');
    if (refreshCaptchaBtn) {
        refreshCaptchaBtn.addEventListener('click', function() {
            generateNewCaptcha();
        });
    }
    
    // Обработчик кнопки отмены
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            contactForm.style.display = 'none';
            toggleBtn.classList.remove('expanded');
            toggleBtn.querySelector('.toggle-text').textContent = originalText;
            form.reset();
            hideMessage();
        });
    }
    
    // Обработчик отправки формы
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Проверяем капчу перед отправкой
            const captchaInput = form.querySelector('#contact_captcha');
            const captchaQuestion = form.querySelector('.captcha-question');
            
            if (captchaInput && captchaQuestion) {
                const userAnswer = parseInt(captchaInput.value);
                const questionText = captchaQuestion.textContent;
                
                // Извлекаем числа из вопроса (например: "3 + 2 = ?")
                const numbers = questionText.match(/(\d+)\s*\+\s*(\d+)/);
                if (numbers) {
                    const num1 = parseInt(numbers[1]);
                    const num2 = parseInt(numbers[2]);
                    const correctAnswer = num1 + num2;
                    
                    if (userAnswer !== correctAnswer) {
                        showMessage('Incorrect captcha answer. Please try again.', 'error');
                        // Генерируем новую капчу
                        generateNewCaptcha();
                        return;
                    }
                }
            }
            
            const formData = new FormData(form);
            const submitBtn = form.querySelector('.submit-btn');
            
            // Показываем индикатор загрузки
            const originalBtnText = submitBtn.textContent;
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;
            
            // Отправляем AJAX запрос
            fetch(form.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage('Message sent successfully!', 'success');
                    form.reset();
                    // Автоматически скрываем форму через 3 секунды
                    setTimeout(() => {
                        contactForm.style.display = 'none';
                        toggleBtn.classList.remove('expanded');
                        toggleBtn.querySelector('.toggle-text').textContent = originalText;
                    }, 3000);
                } else {
                    showMessage(data.message || 'An error occurred while sending the message.', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('An error occurred while sending the message.', 'error');
            })
            .finally(() => {
                // Восстанавливаем кнопку
                submitBtn.textContent = originalBtnText;
                submitBtn.disabled = false;
            });
        });
    }
    
    // Функция показа сообщения
    function showMessage(message, type) {
        formMessage.textContent = message;
        formMessage.className = 'form-message ' + type;
        formMessage.style.display = 'block';
        
        // Автоматически скрываем сообщение через 5 секунд
        setTimeout(hideMessage, 5000);
    }
    
    // Функция скрытия сообщения
    function hideMessage() {
        formMessage.style.display = 'none';
    }
    
    // Функция генерации новой капчи
    function generateNewCaptcha() {
        const num1 = Math.floor(Math.random() * 10) + 1;
        const num2 = Math.floor(Math.random() * 10) + 1;
        const captchaQuestion = document.querySelector('.captcha-question');
        const captchaInput = document.querySelector('#contact_captcha');
        
        if (captchaQuestion && captchaInput) {
            captchaQuestion.textContent = num1 + ' + ' + num2 + ' = ?';
            captchaInput.value = '';
            captchaInput.focus();
        }
    }
    
    // Валидация формы в реальном времени
    const inputs = form.querySelectorAll('input[required], textarea[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                validateField(this);
            }
        });
    });
    
    function validateField(field) {
        const value = field.value.trim();
        const fieldType = field.type;
        
        // Убираем предыдущие классы ошибок
        field.classList.remove('error', 'success');
        
        if (!value) {
            field.classList.add('error');
            return false;
        }
        
        // Дополнительная валидация для email
        if (fieldType === 'email') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                field.classList.add('error');
                return false;
            }
        }
        
        field.classList.add('success');
        return true;
    }
});
