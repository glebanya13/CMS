<?php

namespace Drupal\news\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides the "News" block.
 *
 * @Block(
 *   id = "news_block",
 *   admin_label = @Translation("News block"),
 *   category = @Translation("News")
 * )
 */
class NewsBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build(): array {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('This is a news block'),
    ];
  }

}

