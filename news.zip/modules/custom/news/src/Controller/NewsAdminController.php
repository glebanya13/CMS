<?php

namespace Drupal\news\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Returns the News admin placeholder page.
 */
class NewsAdminController extends ControllerBase {

  /**
   * Displays the News configuration placeholder page.
   */
  public function view(): array {
    // Return an empty render array so only the News page title is shown.
    return [
      '#type' => 'markup',
      '#markup' => '',
    ];
  }

}

