<?php

namespace Drupal\table_creator\Form;

use Drupal\Core\Database\Connection;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides an admin form to manually create the custom table.
 */
class TableCreatorForm extends FormBase {

  /**
   * The database connection.
   */
  protected Connection $connection;

  /**
   * The time service.
   */
  protected TimeInterface $time;

  /**
   * Constructs the form object.
   */
  public function __construct(Connection $connection, TimeInterface $time) {
    $this->connection = $connection;
    $this->time = $time;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): self {
    return new static(
      $container->get('database'),
      $container->get('datetime.time')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'table_creator_admin_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $form['#tree'] = TRUE;

    $form['wrapper'] = [
      '#type' => 'container',
      '#attributes' => [
        'id' => 'table-creator-form-wrapper',
      ],
    ];

    $form['wrapper']['table_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Table machine name'),
      '#description' => $this->t('Use lowercase letters, numbers, and underscores only. Example: custom_data_records'),
      '#required' => TRUE,
      '#maxlength' => 64,
    ];

    $form['wrapper']['columns'] = [
      '#type' => 'table',
      '#header' => [
        $this->t('Column machine name'),
        $this->t('Label'),
        $this->t('Type'),
        $this->t('Length'),
        $this->t('Required'),
        $this->t('Operations'),
      ],
      '#empty' => $this->t('No columns have been added yet.'),
      '#tree' => TRUE,
    ];

    $columns = $form_state->get('columns') ?? [];
    if (empty($columns)) {
      $columns[] = [
        'name' => '',
        'label' => '',
        'type' => 'varchar',
        'length' => 255,
        'required' => TRUE,
      ];
      $form_state->set('columns', $columns);
    }

    foreach ($columns as $delta => $column) {
      $form['wrapper']['columns'][$delta]['name'] = [
        '#type' => 'textfield',
        '#default_value' => $column['name'],
        '#required' => TRUE,
      ];
      $form['wrapper']['columns'][$delta]['label'] = [
        '#type' => 'textfield',
        '#default_value' => $column['label'],
        '#required' => TRUE,
      ];
      $form['wrapper']['columns'][$delta]['type'] = [
        '#type' => 'select',
        '#default_value' => $column['type'],
        '#options' => $this->getTypeOptions(),
        '#required' => TRUE,
      ];
      $form['wrapper']['columns'][$delta]['length'] = [
        '#type' => 'number',
        '#default_value' => $column['length'] ?? 255,
        '#min' => 1,
        '#max' => 1024,
        '#states' => [
          'visible' => [
            ':input[name="wrapper[columns][' . $delta . '][type]"]' => ['value' => 'varchar'],
          ],
        ],
      ];
      $form['wrapper']['columns'][$delta]['required'] = [
        '#type' => 'checkbox',
        '#default_value' => $column['required'],
      ];
      $form['wrapper']['columns'][$delta]['remove'] = [
        '#type' => 'submit',
        '#value' => $this->t('Remove'),
        '#name' => 'remove_column_' . $delta,
        '#submit' => ['::removeColumnSubmit'],
        '#ajax' => [
          'callback' => '::ajaxRefresh',
          'wrapper' => 'table-creator-form-wrapper',
        ],
        '#limit_validation_errors' => [],
      ];
    }

    $form['wrapper']['add_column'] = [
      '#type' => 'submit',
      '#value' => $this->t('Add column'),
      '#submit' => ['::addColumnSubmit'],
      '#ajax' => [
        'callback' => '::ajaxRefresh',
        'wrapper' => 'table-creator-form-wrapper',
      ],
      '#limit_validation_errors' => [],
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];

    $form['actions']['create_table'] = [
      '#type' => 'submit',
      '#value' => $this->t('Create table'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $table_name = $form_state->getValue(['wrapper', 'table_name']);
    $column_values = $form_state->getValue(['wrapper', 'columns']) ?? [];
    $columns = [];

    foreach ($column_values as $column) {
      if (empty($column['name'])) {
        continue;
      }
      $columns[] = $column;
    }

    if (empty($columns)) {
      $this->messenger()->addError($this->t('Add at least one column before creating the table.'));
      return;
    }

    if (!$this->isValidMachineName($table_name)) {
      $this->messenger()->addError($this->t('The table name can only contain lowercase letters, numbers, and underscores.'));
      return;
    }

    $schema = $this->connection->schema();

    if ($schema->tableExists($table_name)) {
      $schema->dropTable($table_name);
      $this->messenger()->addWarning($this->t('Existing table %name dropped.', ['%name' => $table_name]));
    }

    $fields = $this->buildFieldsFromColumns($columns);
    $schema->createTable($table_name, [
      'description' => 'Custom table created via Table Creator.',
      'fields' => $fields,
      'primary key' => ['id'],
    ]);

    $this->messenger()->addStatus($this->t('Table %name created with @count columns.', [
      '%name' => $table_name,
      '@count' => count($fields),
    ]));

    $form_state->setValue('columns', []);
    $form_state->set('columns', []);
  }

  /**
   * Adds a new column row to the form.
   */
  public function addColumnSubmit(array &$form, FormStateInterface $form_state): void {
    $columns = $form_state->get('columns') ?? [];
    $columns[] = [
      'name' => '',
      'label' => '',
      'type' => 'varchar',
      'length' => 255,
      'required' => TRUE,
    ];
    $form_state->set('columns', $columns);
    $form_state->setRebuild();
  }

  /**
   * Removes a column.
   */
  public function removeColumnSubmit(array &$form, FormStateInterface $form_state): void {
    $trigger = $form_state->getTriggeringElement();
    $name = $trigger['#name'];
    if (preg_match('/remove_column_(\d+)/', $name, $matches)) {
      $index = (int) $matches[1];
      $columns = $form_state->get('columns') ?? [];
      if (isset($columns[$index])) {
        unset($columns[$index]);
        $columns = array_values($columns);
        $form_state->set('columns', $columns);
      }
    }
    $form_state->setRebuild();
  }

  /**
   * Ajax callback to rebuild the form.
   */
  public function ajaxRefresh(array &$form, FormStateInterface $form_state): array {
    return $form['wrapper'];
  }

  /**
   * Builds field schema from column definitions.
   */
  protected function buildFieldsFromColumns(array $columns): array {
    $fields = [
      'id' => [
        'type' => 'serial',
        'unsigned' => TRUE,
        'not null' => TRUE,
      ],
    ];

    foreach ($columns as $column) {
      $field = [
        'description' => $column['label'] ?? $column['name'],
        'type' => $column['type'],
        'not null' => !empty($column['required']),
      ];

      if ($column['type'] === 'varchar' && !empty($column['length'])) {
        $field['length'] = (int) $column['length'];
      }

      $fields[$column['name']] = $field;
    }

    return $fields;
  }

  /**
   * Provides type options.
   */
  protected function getTypeOptions(): array {
    return [
      'varchar' => $this->t('Text (varchar)'),
      'text' => $this->t('Long text'),
      'int' => $this->t('Integer'),
      'numeric' => $this->t('Numeric'),
      'datetime' => $this->t('Date/time'),
    ];
  }

  /**
   * Validates a machine name.
   */
  protected function isValidMachineName(string $name): bool {
    return (bool) preg_match('/^[a-z0-9_]+$/', $name);
  }

}

